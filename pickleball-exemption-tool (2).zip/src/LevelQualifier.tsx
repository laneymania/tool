
export default function LevelQualifier() {
  return (
    <div>
      <h1>Pickleball Exemption Tool</h1>
      <p>This is a placeholder. Replace with your LevelQualifier component.</p>
    </div>
  );
}
